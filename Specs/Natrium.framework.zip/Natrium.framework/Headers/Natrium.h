@import Foundation;

FOUNDATION_EXPORT double NatriumVersionNumber;

FOUNDATION_EXPORT const unsigned char NatriumVersionString[];
